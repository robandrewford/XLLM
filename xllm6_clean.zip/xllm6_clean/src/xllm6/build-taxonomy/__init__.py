"""Build-taxonomy package for XLLM6."""
